<?php
    if (!isset($_GET["condition"])) {
        echo "Merci de bien vouloir cocher les CGU";
    }
    else if (!isset($_GET["prenom"])) {
        echo "Merci de remplir tout les champs";
    }
    else if (!isset($_GET["nom"])) {
        echo "Merci de remplir tout les champs";
    }
    else if (!isset($_GET["email"])) {
        echo "Merci de remplir tout les champs";
    }
    else if (!isset($_GET["sujet"])) {
        echo "Merci de remplir tout les champs";
    }
    else if (!isset($_GET["message"])) {
        echo "Merci de remplir tout les champs";
    }
    else {
        $prenom=$_GET["prenom"];
        $nom=$_GET["nom"];
        $email=$_GET["email"];
        $message=$_GET["message"];
        echo "Bonjour $nom $prenom, nous allons prendre contact avec vous rapidement. Cordialement";
        mail($email, "Contact via le site",$message);
    }
?>