<?php
    $titre="Accueil";
    require_once 'header.php';
?>
<body>
    <img src="photo.jpeg" alt="Photo">
    <p> Bonjour je m'appelle Alexandre, je suis docteur en Chimie, et je me forme au développement web. </p>
    <p> J'ai fait de la chimie pendant 8 ans.</p>
    <p> Je suis maintenant inscrit à la Fabrique du Numérique pour apprendre les bases du développement web</p>
</body>