<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php
require_once('connexion.php');
$action = $_GET['action'];
if ($action == 'add') {
    $nom ="";
    $quantite="";
    $idinf="";
    $traitement="traitement_ajout.php";
} 
else if ($action =='edit') {
    $id = $_GET['id'];
    $requete = "SELECT * FROM articles where id=$id"; // écriture de la requête
    $reponse = $bdd->query($requete); // réalisation de la requête
    foreach ($reponse as $info) {
        $nom = $info['nom'];
        $quantite = $info['quantite'];
        $idinf = $info['id'];
        $traitement="traitement_update.php";
    }
}
?>
<form action="<?= $traitement ?>" method="GET">
    <input type="hidden" name="id" value="<?= $idinf?>">
    Nom de l'article :<input type="text" name="nom" value="<?= $nom ?>"><br>
    Quantité :<input type="text" name="quantite" value="<?= $quantite ?>"><br>
    <input type="submit">
</form>
