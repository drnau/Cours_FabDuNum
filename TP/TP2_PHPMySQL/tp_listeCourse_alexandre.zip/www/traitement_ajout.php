<?php
require_once('connexion.php');
$nom = $_GET["nom"];
$quantite = $_GET["quantite"];
    $requete="INSERT INTO articles (nom, quantite) VALUES ('$nom', '$quantite') ";
    $bdd->query($requete); // réalisation de la requête
    header ('Location: index.php');
