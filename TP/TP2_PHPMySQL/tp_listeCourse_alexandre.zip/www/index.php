<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="container">
<?php
require_once('connexion.php');
$requete = 'SELECT * FROM articles '; // écriture de la requête
$reponse = $bdd->query($requete); // réalisation de la requête
foreach ($reponse as $info) {
    $id = $info['id'];
    $nom=$info['nom'];
    $quantite=$info['quantite'];
    echo " Article : " . $info['nom'] . "<br> quantité : " . $info['quantite'] . "<br><br> <a href='user.php?id=$id'><button  class='btn btn-outline-secondary'>Voir</button></a> <a href='formulaire.php?id=$id&action=edit'><button  class='btn btn-outline-secondary'>Modifier</button></a> <a href='delete.php?id=$id'><button  class='btn btn-outline-danger'>X</button></a><br><hr>";
}

?>
<a href="formulaire.php?action=add"><button class="btn btn-outline-success">Ajouter un nouvel article</button></a>
</div>